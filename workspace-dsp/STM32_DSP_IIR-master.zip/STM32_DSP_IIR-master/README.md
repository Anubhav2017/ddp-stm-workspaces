# STM32 IIR Audio Filter with I2S 

I realized a simple IIR filter based on a I2S audio input / output audio stream.  
Further details described in the documentation-PDF file.  
Check out my YouTube video where I have explained everything in detail: https://www.youtube.com/watch?v=lNBrGOk0XzE
