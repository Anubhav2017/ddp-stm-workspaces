# STM32 PDM Microphone with I2S audio output

I made an example project where I want to show you how to interface a PDM microphone (basically the mic on the evalboard) to the STM32 and how to output the sound to an external I2S DAC.

Check out my YouTube video where I have explained everything in detail: 
https://www.youtube.com/watch?v=JuXKeyFraF4
